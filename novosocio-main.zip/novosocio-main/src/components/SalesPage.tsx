import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  CheckCircle, 
  Play, 
  Users, 
  Instagram, 
  Youtube, 
  ChevronDown, 
  ChevronUp, 
  ShieldCheck, 
  Zap, 
  Target, 
  Globe, 
  Search, 
  Layout, 
  Lock,
  Gift
} from 'lucide-react';

import PurchaseNotification from './PurchaseNotification';

const modules = [
  {
    title: "Estrutura que Fatura",
    description: "Crie uma estrutura que vende no automático, sem precisar aparecer.",
    icon: <Layout className="w-6 h-6 text-orange-500" />
  },
  {
    title: "Tráfego Anti-Bloqueio",
    description: "Meta Ads passo a passo, focado em organização e escala.",
    icon: <Target className="w-6 h-6 text-orange-500" />
  },
  {
    title: "Anúncios Chiclete",
    description: "Criação de anúncios que perseguem seu cliente de grudam na mente.",
    icon: <Zap className="w-6 h-6 text-orange-500" />
  },
  {
    title: "Caixa Rápido",
    description: "Produtos e criativos prontos para você começar a faturar hoje.",
    icon: <Zap className="w-6 h-6 text-orange-500" />
  },
  {
    title: "Espionagem Elite",
    description: "Engenharia reversa para copiar o que já funciona no mercado.",
    icon: <Search className="w-6 h-6 text-orange-500" />
  },
  {
    title: "Mercado Internacional",
    description: "Venda em Euro e Dólar saindo do zero com baixo investimento.",
    icon: <Globe className="w-6 h-6 text-orange-500" />
  }
];

const faqs = [
  {
    question: "Qual o tempo de acesso ao curso?",
    answer: "Você terá acesso vitalício a todas as aulas e atualizações do Método Destrava 2.0."
  },
  {
    question: "Funciona para afiliados?",
    answer: "Sim! O método foi desenhado tanto para quem quer vender produtos próprios quanto para quem deseja atuar como afiliado profissional."
  },
  {
    question: "Quando recebo as aulas?",
    answer: "O acesso é imediato! Assim que o pagamento for confirmado, você receberá os dados de acesso no seu e-mail."
  },
  {
    question: "Vou receber um produto pronto para vender?",
    answer: "Sim, dentro do método entregamos produtos validados e prontos para você começar a aplicar as estratégias imediatamente."
  }
];

const testimonials = [
  { id: 1, url: "https://www.youtube.com/watch?v=sQBNBVsNTmY", thumbnail: "https://img.youtube.com/vi/sQBNBVsNTmY/maxresdefault.jpg" },
  { id: 2, url: "https://www.youtube.com/watch?v=pYifEW3ceMo", thumbnail: "https://img.youtube.com/vi/pYifEW3ceMo/maxresdefault.jpg" },
  { id: 3, url: "https://www.youtube.com/watch?v=RdoHcyYrVsA", thumbnail: "https://img.youtube.com/vi/RdoHcyYrVsA/maxresdefault.jpg" },
  { id: 4, url: "https://www.youtube.com/watch?v=eu01B7eTrBA", thumbnail: "https://img.youtube.com/vi/eu01B7eTrBA/maxresdefault.jpg" },
  { id: 5, url: "https://www.youtube.com/watch?v=DmZgwWBwVxY", thumbnail: "https://img.youtube.com/vi/DmZgwWBwVxY/maxresdefault.jpg" },
  { id: 6, url: "https://www.youtube.com/watch?v=7J0o1m1sFBM", thumbnail: "https://img.youtube.com/vi/7J0o1m1sFBM/maxresdefault.jpg" },
];

export default function SalesPage() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    const urlDestino = "https://www.rendadigital.net/socio-promo";
    
    // Push initial state
    window.history.pushState(null, null, window.location.href);
    
    const handlePopState = () => {
      window.location.href = urlDestino;
    };

    window.addEventListener('popstate', handlePopState);
    
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-orange-500 selection:text-white">
      <PurchaseNotification />
      
      {/* Top Bar */}
      <div className="bg-orange-600 py-3 text-center px-4">
        <div className="text-sm font-bold uppercase tracking-wider">
          Oferta exclusiva válida até {new Date().toLocaleDateString('pt-BR')}
        </div>
      </div>
      <div className="bg-[#0a0a0a] py-2 text-center px-4 border-b border-gray-900">
        <div className="text-xs md:text-sm font-black uppercase tracking-[0.2em] whitespace-nowrap text-orange-500">
          🚀 A Nova Era do Marketing Digital
        </div>
      </div>

      {/* Hero Section */}
      <section className="container mx-auto px-4 pt-8 pb-16 text-center relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-orange-600/10 blur-[150px] -z-10"></div>
        
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-7xl lg:text-8xl font-black mb-6 leading-[1.1] tracking-tighter"
        >
          Novo Sócio Digital: A Revolução <span className="text-orange-500">Silenciosa</span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-base md:text-2xl lg:text-3xl text-gray-300 mb-6 max-w-3xl mx-auto font-medium leading-relaxed"
        >
          Esqueça o "trabalho duro". Use nosso <span className="text-white font-bold underline decoration-orange-500 decoration-4">Método Completo + IA</span> para clonar o que já vende e faturar até <span className="text-orange-500 font-black">5MIL</span> sem precisar aparecer.
        </motion.p>

        {/* Video Container with Glassmorphism */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="relative max-w-4xl mx-auto p-1.5 rounded-[2rem] bg-gradient-to-br from-orange-600/20 to-transparent border border-white/10 backdrop-blur-sm shadow-2xl shadow-orange-500/20 mb-10 group"
        >
          <div className="aspect-video bg-black rounded-[1.5rem] overflow-hidden relative">
            <iframe
              src="https://play.tynk.ai/p/87bfbca1-530c-4021-a7e4-277f3601ab87"
              className="w-full h-full"
              style={{ aspectRatio: '16/9', border: 'none' }}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
        </motion.div>

        <div className="flex flex-col items-center gap-6">
          <motion.button
            onClick={() => document.getElementById('comparison')?.scrollIntoView({ behavior: 'smooth' })}
            whileHover={{ scale: 1.05, boxShadow: "0 0 40px rgba(234,88,12,0.4)" }}
            whileTap={{ scale: 0.95 }}
            className="bg-orange-600 hover:bg-orange-500 text-white text-xl md:text-3xl font-black py-5 px-8 md:py-8 md:px-16 rounded-full transition-all uppercase tracking-tighter shadow-2xl cursor-pointer"
          >
            Quero Acesso ao Método + IAs
          </motion.button>
          <div className="flex items-center gap-4 text-gray-400 font-bold">
            <div className="flex -space-x-3">
              {[1,2,3,4].map(i => (
                <img key={i} src={`https://i.pravatar.cc/100?u=${i}`} className="w-10 h-10 rounded-full border-2 border-[#0a0a0a]" alt="User" />
              ))}
            </div>
            <p className="text-sm">Junte-se a <span className="text-white">+30.000</span> alunos satisfeitos</p>
          </div>
        </div>
      </section>

      {/* Comparison Section (Neuroscience: Pain vs Pleasure) */}
      <section id="comparison" className="py-24 bg-white text-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-6xl font-black mb-6 tracking-tighter">
              O Fim do <span className="text-orange-600 italic">Marketing Amador</span>
            </h2>
            <p className="text-gray-600 text-xl max-w-2xl mx-auto">
              Por que 97% das pessoas falham enquanto nossos alunos dominam o mercado?
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            <div className="bg-gray-50 p-10 rounded-[2.5rem] border border-gray-200">
              <h3 className="text-2xl font-black mb-8 flex items-center gap-3 text-red-600">
                O Jeito Velho (Lento e Doloroso)
              </h3>
              <ul className="space-y-6">
                {[
                  "Gastar horas criando conteúdo que ninguém vê",
                  "Queimar dinheiro com anúncios que não convertem",
                  "Tentar adivinhar o que o cliente quer comprar",
                  "Ficar preso em tarefas manuais e repetitivas",
                  "Depender da sorte para fazer uma venda"
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-4 text-gray-500">
                    <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center shrink-0 mt-1">
                      <span className="text-red-600 font-bold">✕</span>
                    </div>
                    <span className="font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-orange-600 p-10 rounded-[2.5rem] text-white shadow-2xl shadow-orange-600/30">
              <h3 className="text-2xl font-black mb-8 flex items-center gap-3">
                O Jeito Sócio Digital (IA + Escala)
              </h3>
              <ul className="space-y-6">
                {[
                  "IA que clona estruturas milionárias em segundos",
                  "Anúncios validados que perseguem o cliente",
                  "Produtos prontos com alta taxa de conversão",
                  "Escala automática sem precisar aparecer",
                  "Faturamento previsível e recorrente"
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-4">
                    <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center shrink-0 mt-1">
                      <CheckCircle className="w-4 h-4 text-white" />
                    </div>
                    <span className="font-bold">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Modules Section */}
      <section className="bg-[#111] py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-5xl font-black text-center mb-4">
            O Que Você vai <span className="text-orange-500">Aprender</span>
          </h2>
          <p className="text-gray-400 text-center mb-16 max-w-2xl mx-auto">
            Módulos práticos pensados para levar você do iniciante ao faturamento recorrente.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {modules.map((module, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-gray-900/50 p-8 rounded-2xl border border-gray-800 hover:border-orange-500/50 transition-colors group"
              >
                <div className="mb-6 bg-gray-800 w-14 h-14 rounded-xl flex items-center justify-center group-hover:bg-orange-600 transition-colors">
                  {React.cloneElement(module.icon as React.ReactElement, { className: "w-8 h-8 text-orange-500 group-hover:text-white" })}
                </div>
                <h3 className="text-xl font-bold mb-3">{module.title}</h3>
                <p className="text-gray-400 leading-relaxed">{module.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Bonuses Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-orange-600/5 blur-[120px] rounded-full"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <motion.span 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              className="bg-orange-600/20 text-orange-500 px-4 py-1 rounded-full text-sm font-black uppercase tracking-widest mb-4 inline-block border border-orange-600/30"
            >
              Exclusivo & Limitado
            </motion.span>
            <h2 className="text-4xl md:text-6xl font-black mb-6">
              Bônus <span className="text-orange-500 italic">Irresistíveis</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Ao entrar hoje, você não leva apenas um curso. Você recebe o arsenal tecnológico que os grandes players usam para dominar o mercado em 2026.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Bonus 1 */}
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="group relative bg-gradient-to-br from-gray-900 to-black p-1 rounded-[2.5rem] overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-red-600 opacity-20 group-hover:opacity-40 transition-opacity"></div>
              <div className="relative bg-[#0a0a0a] p-8 md:p-12 rounded-[2.4rem] h-full flex flex-col">
                <div className="flex items-start justify-between mb-8">
                  <div className="bg-orange-600/20 p-4 rounded-2xl border border-orange-600/30">
                    <Zap className="w-10 h-10 text-orange-500" />
                  </div>
                  <span className="text-orange-500 font-black text-xl">BÔNUS #01</span>
                </div>
                
                <h3 className="text-3xl font-black mb-4 leading-tight uppercase">
                  DOMINANDO O <span className="text-orange-500">GOOGLE GEMINI 2026</span>
                </h3>
                <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                  Te ensinaremos a extrair o poder máximo da IA mais avançada do planeta para criar textos que hipnotizam e vendem em minutos. É o fim do bloqueio criativo: você terá anúncios, VSLs e páginas de vendas prontas em segundos.
                  <span className="text-white font-bold block mt-2 italic">"Uma persuasão que beira o sobrenatural, gerando copys que vendem enquanto você dorme."</span>
                </p>
                
                <div className="mt-auto pt-6 border-t border-gray-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="text-sm font-bold text-gray-300">VALOR: <span className="line-through text-gray-500">R$ 497,00</span></span>
                  </div>
                  <span className="bg-green-600/20 text-green-500 px-3 py-1 rounded-lg text-xs font-black uppercase tracking-tighter">LIBERADO GRÁTIS</span>
                </div>
              </div>
            </motion.div>

            {/* Bonus 2 */}
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="group relative bg-gradient-to-br from-gray-900 to-black p-1 rounded-[2.5rem] overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-red-600 opacity-20 group-hover:opacity-40 transition-opacity"></div>
              <div className="relative bg-[#0a0a0a] p-8 md:p-12 rounded-[2.4rem] h-full flex flex-col">
                <div className="flex items-start justify-between mb-8">
                  <div className="bg-orange-600/20 p-4 rounded-2xl border border-orange-600/30">
                    <Target className="w-10 h-10 text-orange-500" />
                  </div>
                  <span className="text-orange-500 font-black text-xl">BÔNUS #02</span>
                </div>
                
                <h3 className="text-3xl font-black mb-4 leading-tight uppercase">
                  O SCRIPT SECRETO <span className="text-orange-500">DO GEMINI</span>
                </h3>
                <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                  Tenha em mãos o comando exato (prompt) que obriga a IA a gerar copys de alta conversão. Enquanto seus concorrentes perdem horas tentando escrever algo que preste, você aperta um botão e recebe uma copy que converte curiosos em clientes apaixonados.
                  <span className="text-white font-bold block mt-2 italic">"Chega a ser covardia com quem não tem acesso a isso. Uma vantagem injusta no mercado."</span>
                </p>
                
                <div className="mt-auto pt-6 border-t border-gray-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="text-sm font-bold text-gray-300">VALOR: <span className="line-through text-gray-500">R$ 397,00</span></span>
                  </div>
                  <span className="bg-green-600/20 text-green-500 px-3 py-1 rounded-lg text-xs font-black uppercase tracking-tighter">LIBERADO GRÁTIS</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mentor Section */}
      <section className="py-24 container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-12 max-w-5xl mx-auto">
          <div className="w-64 h-64 md:w-80 md:h-80 relative">
            <div className="absolute inset-0 bg-orange-600 rounded-full blur-3xl opacity-20"></div>
            <img 
              src="https://rendadigital.net/wp-content/uploads/2026/04/fotoJosueBonfim.webp" 
              alt="Josué Bonfim" 
              className="w-full h-full object-cover rounded-full border-4 border-orange-600 relative z-10"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex-1 text-center md:text-left">
            <p className="text-orange-500 font-bold uppercase tracking-widest mb-2">Quem é o seu mentor?</p>
            <h2 className="text-4xl md:text-6xl font-black mb-6">Josué Bonfim</h2>
            <div className="space-y-4 text-gray-300 text-lg leading-relaxed">
              <p>Empreendedor há mais de 16 anos, dos quais 12 são no marketing digital. Sendo um dos pioneiros nas vendas como afiliado usando o Facebook ads.</p>
              <p>Tenho mais de 30 mil alunos em treinamentos próprios, além do faturamento milionário como afiliado!</p>
              <p className="font-bold text-white italic">"Sou o cara que não precisa aparecer para vender, não precisa de seguidor, nem de afiliados para vender os próprios produtos."</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-[#050505] py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-black mb-4">
              Veja os depoimentos <span className="text-orange-500">dos meus alunos</span>
            </h2>
            <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto">
              Pessoas reais que saíram do zero e hoje faturam com meu método.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <motion.a 
                key={t.id}
                href={t.url}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.02 }}
                className="aspect-video bg-gray-900 rounded-xl overflow-hidden border border-gray-800 relative group cursor-pointer block"
              >
                <img src={t.thumbnail} alt="Testimonial" className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center shadow-lg">
                    <Play className="w-6 h-6 text-white fill-current" />
                  </div>
                </div>
              </motion.a>
            ))}
          </div>
        </div>
      </section>

      {/* Authority Section */}
      <section className="py-24 container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-5xl font-black mb-16">Autoridade reconhecida</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-4xl mx-auto">
          <div className="bg-gray-900/50 p-8 rounded-3xl border border-gray-800">
            <div className="flex items-center justify-center gap-4 mb-6">
              <Instagram className="w-10 h-10 text-pink-500" />
              <span className="text-4xl font-black">+182k</span>
            </div>
            <p className="text-gray-400 font-bold uppercase">No Instagram!</p>
            <div className="mt-8 rounded-xl overflow-hidden border border-gray-800">
              <img src="https://rendadigital.net/wp-content/uploads/2026/04/instagram-josue.webp" alt="Instagram Authority" className="w-full" referrerPolicy="no-referrer" />
            </div>
          </div>

          <div className="bg-gray-900/50 p-8 rounded-3xl border border-gray-800">
            <div className="flex items-center justify-center gap-4 mb-6">
              <Youtube className="w-10 h-10 text-red-600" />
              <span className="text-4xl font-black">+64k</span>
            </div>
            <p className="text-gray-400 font-bold uppercase">No YouTube!</p>
            <div className="mt-8 rounded-xl overflow-hidden border border-gray-800">
              <img src="https://rendadigital.net/wp-content/uploads/2026/04/Captura-de-Tela-2025-10-31-as-14.21.05.webp" alt="YouTube Authority" className="w-full" referrerPolicy="no-referrer" />
            </div>
          </div>
        </div>
      </section>

      {/* Offer Section */}
      <section id="checkout" className="py-24 bg-gradient-to-b from-[#0a0a0a] to-orange-950/10">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-5xl font-black text-center mb-16">
            Escolha o seu <span className="text-orange-500">Plano</span>
          </h2>
          
          <div className="flex flex-col lg:flex-row justify-center items-stretch gap-8 max-w-6xl mx-auto">
            {/* Plano Essencial */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex-1 bg-white text-gray-900 rounded-[2.5rem] p-8 md:p-12 shadow-xl border border-gray-100 flex flex-col"
            >
              <div className="text-center mb-8">
                <h3 className="text-2xl font-black uppercase tracking-tighter mb-4">PLANO ESSENCIAL</h3>
                <div className="flex items-center justify-center gap-3">
                  <span className="text-gray-400 line-through text-lg italic">R$ 47</span>
                  <div className="text-6xl font-black flex items-start">
                    <span className="text-2xl mt-2 mr-1">R$</span>
                    <span>12,90</span>
                  </div>
                </div>
              </div>

              <ul className="space-y-5 mb-12 flex-grow">
                {[
                  "Acesso completo às aulas do Método Destrava 2.0",
                  "Passo a passo direto para fazer a primeira venda",
                  "Estrutura simples para iniciantes",
                  "Método validado",
                  "Produto validado pronto para começar",
                  "Direcionamento claro para aplicar imediatamente"
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-gray-700 font-medium">
                    <CheckCircle className="w-6 h-6 text-orange-500 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              <motion.a
                href="https://go.atomopay.com.br/xtxmp0zeuv"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full bg-[#0f172a] hover:bg-black text-white font-black py-4 md:py-6 rounded-2xl shadow-lg transition-all uppercase text-xl tracking-tighter text-center block"
              >
                PLANO ESSENCIAL
              </motion.a>
            </motion.div>

            {/* Acesso VIP Acelerado */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex-1 bg-white text-gray-900 rounded-[2.5rem] p-8 md:p-12 shadow-2xl border-4 border-orange-600 relative flex flex-col"
            >
              <div className="absolute -top-5 right-8 bg-orange-600 text-white text-xs font-black px-4 py-2 rounded-lg uppercase tracking-widest shadow-lg">
                MAIS ESCOLHIDO
              </div>

              <div className="text-center mb-8">
                <h3 className="text-2xl font-black uppercase tracking-tighter mb-4 text-orange-600 flex items-center justify-center gap-2">
                  ACESSO VIP ACELERADO <Zap className="w-6 h-6 fill-current" />
                </h3>
                <div className="flex items-center justify-center gap-3">
                  <span className="text-gray-400 line-through text-lg italic">R$ 97</span>
                  <div className="text-6xl font-black text-orange-600 flex items-start">
                    <span className="text-2xl mt-2 mr-1">R$</span>
                    <span>37</span>
                  </div>
                </div>
              </div>

              <ul className="space-y-5 mb-12 flex-grow">
                {[
                  "Tudo do Plano Essencial",
                  "+ Produtos Extras (escala)",
                  "1 ENCONTRO AO VIVO PARA TIRAR DÚVIDAS",
                  "Acesso ao Grupo VIP no WhatsApp",
                  "Acesso à Mentoria de Produto Físico",
                  "Aulas semanais dentro da mentoria",
                  "Ambiente de crescimento acelerado",
                  "DOMINANDO O GOOGLE GEMINI 2026: A MÁQUINA DE COPY QUE NUNCA DORME",
                  "O SCRIPT SECRETO DO GEMINI: CONVERSÃO QUE CHEGA A SER INJUSTA"
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-gray-800 font-black italic uppercase text-sm md:text-base">
                    {item.includes("IA") || item.includes("GEMINI") ? (
                      <Gift className="w-6 h-6 text-orange-500 shrink-0" />
                    ) : (
                      <CheckCircle className="w-6 h-6 text-orange-500 shrink-0" />
                    )}
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              <div className="space-y-6">
                <motion.a
                  href="https://go.atomopay.com.br/sprhw"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white font-black py-4 md:py-6 rounded-2xl shadow-xl shadow-orange-600/20 transition-all uppercase text-xl tracking-tighter text-center block"
                >
                  ACESSO VIP ACELERADO
                </motion.a>

                <div className="bg-red-50 border border-red-100 p-4 rounded-xl text-center">
                  <p className="text-[10px] md:text-xs font-black text-red-500 uppercase tracking-tighter leading-tight">
                    ⚠️ RESTAM APENAS 30 VAGAS PARA ESTE LOTE COM BÔNUS EXCLUSIVOS
                  </p>
                </div>
              </div>
            </motion.div>
          </div>

          <div className="mt-16 flex flex-col items-center gap-4">
            <div className="flex items-center gap-2 text-gray-400">
              <ShieldCheck className="w-8 h-8 text-orange-500" />
              <p className="text-sm font-bold uppercase tracking-widest">Compra 100% Segura • 7 Dias de Garantia</p>
            </div>
            <img 
              src="https://rendadigital.net/wp-content/uploads/2026/04/selo-garantia-7-dias-small-removebg-preview-1.webp" 
              alt="Selo de Garantia" 
              className="w-24 h-24 object-contain"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 container mx-auto px-4 max-w-3xl">
        <h2 className="text-3xl md:text-5xl font-black text-center mb-16">Perguntas Frequentes</h2>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="border border-gray-800 rounded-2xl overflow-hidden">
              <button 
                onClick={() => setOpenFaq(openFaq === index ? null : index)}
                className="w-full p-6 text-left flex items-center justify-between bg-gray-900/50 hover:bg-gray-900 transition-colors"
              >
                <span className="font-bold text-lg">{faq.question}</span>
                {openFaq === index ? <ChevronUp className="text-orange-500" /> : <ChevronDown className="text-gray-500" />}
              </button>
              {openFaq === index && (
                <div className="p-6 bg-gray-900/30 text-gray-400 leading-relaxed border-t border-gray-800">
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-gray-900 text-center">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center gap-8 mb-12">
            <div className="flex items-center gap-4">
              <img 
                src="https://rendadigital.net/wp-content/uploads/2026/04/Novo-Socio-6-1024x256-1.webp" 
                alt="Novo Sócio Digital" 
                className="h-12 md:h-16 object-contain"
                referrerPolicy="no-referrer"
              />
              <div className="w-px h-8 bg-gray-800"></div>
              <div className="text-xl font-bold text-gray-500">MÉTODO DESTRAVA</div>
            </div>
          </div>
          <p className="text-gray-600 text-sm mb-4">osociodigital.com.br | Todos os direitos reservados 2025</p>
          <div className="flex justify-center gap-6 text-xs text-gray-500">
            <a href="#" className="hover:text-orange-500 transition-colors">Termos e condições</a>
            <a href="#" className="hover:text-orange-500 transition-colors">Política de privacidade</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
