import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle } from 'lucide-react';

const names = [
  "Gabriela", "Marcos", "Ana", "João", "Beatriz", "Lucas", "Mariana", "Pedro", 
  "Fernanda", "Ricardo", "Camila", "Bruno", "Letícia", "Rafael", "Juliana", 
  "Gustavo", "Amanda", "Thiago", "Larissa", "Felipe"
];

export default function PurchaseNotification() {
  const [currentName, setCurrentName] = useState("");
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const showNotification = () => {
      const randomName = names[Math.floor(Math.random() * names.length)];
      setCurrentName(randomName);
      setIsVisible(true);

      setTimeout(() => {
        setIsVisible(false);
      }, 5000); // Show for 5 seconds
    };

    // Initial delay before first notification
    const initialTimeout = setTimeout(showNotification, 3000);

    // Interval for subsequent notifications
    const interval = setInterval(() => {
      if (!isVisible) {
        showNotification();
      }
    }, 15000); // Try to show every 15 seconds

    return () => {
      clearTimeout(initialTimeout);
      clearInterval(interval);
    };
  }, [isVisible]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, x: -100, y: 50 }}
          animate={{ opacity: 1, x: 20, y: 0 }}
          exit={{ opacity: 0, x: -100, y: 50 }}
          className="fixed bottom-6 left-6 z-[100] flex items-center gap-3 bg-[#2ecc71] text-white px-6 py-4 rounded-lg shadow-2xl border border-white/10"
        >
          <div className="bg-white/20 p-2 rounded-full">
            <CheckCircle className="w-6 h-6 text-white" />
          </div>
          <p className="font-medium text-sm md:text-base">
            <span className="font-black">{currentName}</span> acabou de comprar
          </p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
