import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  CheckCircle, 
  Play, 
  Users, 
  Instagram, 
  Youtube, 
  ChevronDown, 
  ChevronUp, 
  ShieldCheck, 
  Zap, 
  Target, 
  Globe, 
  Search, 
  Layout, 
  Lock,
  Gift
} from 'lucide-react';

const modules = [
  {
    title: "Estrutura que Fatura",
    description: "Crie uma estrutura que vende no automático, sem precisar aparecer.",
    icon: <Layout className="w-6 h-6 text-orange-500" />
  },
  {
    title: "Tráfego Anti-Bloqueio",
    description: "Meta Ads passo a passo, focado em organização e escala.",
    icon: <Target className="w-6 h-6 text-orange-500" />
  },
  {
    title: "Anúncios Chiclete",
    description: "Criação de anúncios que perseguem seu cliente de grudam na mente.",
    icon: <Zap className="w-6 h-6 text-orange-500" />
  },
  {
    title: "Caixa Rápido",
    description: "Produtos e criativos prontos para você começar a faturar hoje.",
    icon: <Zap className="w-6 h-6 text-orange-500" />
  },
  {
    title: "Espionagem Elite",
    description: "Engenharia reversa para copiar o que já funciona no mercado.",
    icon: <Search className="w-6 h-6 text-orange-500" />
  },
  {
    title: "Mercado Internacional",
    description: "Venda em Euro e Dólar saindo do zero com baixo investimento.",
    icon: <Globe className="w-6 h-6 text-orange-500" />
  }
];

const faqs = [
  {
    question: "Qual o tempo de acesso ao curso?",
    answer: "Você terá acesso vitalício a todas as aulas e atualizações do Método Destrava 2.0."
  },
  {
    question: "Funciona para afiliados?",
    answer: "Sim! O método foi desenhado tanto para quem quer vender produtos próprios quanto para quem deseja atuar como afiliado profissional."
  },
  {
    question: "Quando recebo as aulas?",
    answer: "O acesso é imediato! Assim que o pagamento for confirmado, você receberá os dados de acesso no seu e-mail."
  },
  {
    question: "Vou receber um produto pronto para vender?",
    answer: "Sim, dentro do método entregamos produtos validados e prontos para você começar a aplicar as estratégias imediatamente."
  }
];

const testimonials = [
  { id: 1, url: "https://www.youtube.com/watch?v=sQBNBVsNTmY", thumbnail: "https://img.youtube.com/vi/sQBNBVsNTmY/maxresdefault.jpg" },
  { id: 2, url: "https://www.youtube.com/watch?v=pYifEW3ceMo", thumbnail: "https://img.youtube.com/vi/pYifEW3ceMo/maxresdefault.jpg" },
  { id: 3, url: "https://www.youtube.com/watch?v=RdoHcyYrVsA", thumbnail: "https://img.youtube.com/vi/RdoHcyYrVsA/maxresdefault.jpg" },
  { id: 4, url: "https://www.youtube.com/watch?v=eu01B7eTrBA", thumbnail: "https://img.youtube.com/vi/eu01B7eTrBA/maxresdefault.jpg" },
  { id: 5, url: "https://www.youtube.com/watch?v=DmZgwWBwVxY", thumbnail: "https://img.youtube.com/vi/DmZgwWBwVxY/maxresdefault.jpg" },
  { id: 6, url: "https://www.youtube.com/watch?v=7J0o1m1sFBM", thumbnail: "https://img.youtube.com/vi/7J0o1m1sFBM/maxresdefault.jpg" },
];

export default function SalesPage() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-orange-500 selection:text-white">
      {/* Top Bar */}
      <div className="bg-orange-600 py-2 text-center text-sm font-bold uppercase tracking-wider">
        Oferta exclusiva válida até {new Date().toLocaleDateString('pt-BR')}
      </div>

      {/* Hero Section */}
      <section className="container mx-auto px-4 pt-12 pb-20 text-center">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-6xl font-black mb-6 leading-tight"
        >
          De <span className="text-orange-500">1K a 5K</span> em até 7 dias
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto font-medium"
        >
          Produto validado + Inteligência Artificial + Método Validado. <br className="hidden md:block" />
          <span className="text-white font-bold">Chega de só assistir! É hora de aplicar!</span>
        </motion.p>

        {/* Video Placeholder */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="relative max-w-4xl mx-auto aspect-video bg-gray-900 rounded-2xl border-4 border-gray-800 overflow-hidden shadow-2xl shadow-orange-500/10 mb-12 group cursor-pointer"
        >
          <img 
            src="https://picsum.photos/seed/vsl/1280/720" 
            alt="VSL Thumbnail" 
            className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-20 h-20 bg-orange-600 rounded-full flex items-center justify-center shadow-xl group-hover:scale-110 transition-transform">
              <Play className="w-10 h-10 text-white fill-current ml-1" />
            </div>
          </div>
          <div className="absolute bottom-4 left-4 right-4 text-left">
            <p className="text-sm text-gray-400">Assista ao vídeo para entender o método</p>
          </div>
        </motion.div>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-orange-600 hover:bg-orange-500 text-white text-xl md:text-2xl font-black py-6 px-12 rounded-full shadow-lg shadow-orange-600/30 transition-all uppercase tracking-tighter"
        >
          Quero Comprar com Desconto
        </motion.button>
        <p className="mt-4 text-green-500 flex items-center justify-center gap-2 font-bold animate-pulse">
          <Users className="w-5 h-5" /> Vagas limitadas para a próxima turma
        </p>
      </section>

      {/* Modules Section */}
      <section className="bg-[#111] py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-5xl font-black text-center mb-4">
            O Que Você vai <span className="text-orange-500">Aprender</span>
          </h2>
          <p className="text-gray-400 text-center mb-16 max-w-2xl mx-auto">
            Módulos práticos pensados para levar você do iniciante ao faturamento recorrente.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {modules.map((module, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-gray-900/50 p-8 rounded-2xl border border-gray-800 hover:border-orange-500/50 transition-colors group"
              >
                <div className="mb-6 bg-gray-800 w-14 h-14 rounded-xl flex items-center justify-center group-hover:bg-orange-600 transition-colors">
                  {React.cloneElement(module.icon as React.ReactElement, { className: "w-8 h-8 text-orange-500 group-hover:text-white" })}
                </div>
                <h3 className="text-xl font-bold mb-3">{module.title}</h3>
                <p className="text-gray-400 leading-relaxed">{module.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Bonuses Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-orange-600/5 blur-[120px] rounded-full"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <motion.span 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              className="bg-orange-600/20 text-orange-500 px-4 py-1 rounded-full text-sm font-black uppercase tracking-widest mb-4 inline-block border border-orange-600/30"
            >
              Exclusivo & Limitado
            </motion.span>
            <h2 className="text-4xl md:text-6xl font-black mb-6">
              Bônus <span className="text-orange-500 italic">Irresistíveis</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Ao entrar hoje, você não leva apenas um curso. Você recebe o arsenal tecnológico que os grandes players usam para dominar o mercado em 2026.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Bonus 1 */}
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="group relative bg-gradient-to-br from-gray-900 to-black p-1 rounded-[2.5rem] overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-red-600 opacity-20 group-hover:opacity-40 transition-opacity"></div>
              <div className="relative bg-[#0a0a0a] p-8 md:p-12 rounded-[2.4rem] h-full flex flex-col">
                <div className="flex items-start justify-between mb-8">
                  <div className="bg-orange-600/20 p-4 rounded-2xl border border-orange-600/30">
                    <Zap className="w-10 h-10 text-orange-500" />
                  </div>
                  <span className="text-orange-500 font-black text-xl">BÔNUS #01</span>
                </div>
                
                <h3 className="text-3xl font-black mb-4 leading-tight">
                  IA CLONADORA DE <span className="text-orange-500">QUIZZES 2026</span>
                </h3>
                <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                  A estrutura que mais vende no mundo em 2026 agora na palma da sua mão. Nossa IA clona e cria qualquer página de quiz em segundos. 
                  <span className="text-white font-bold block mt-2">Converta curiosos em compradores com a tecnologia mais lucrativa do ano.</span>
                </p>
                
                <div className="mt-auto pt-6 border-t border-gray-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="text-sm font-bold text-gray-300">VALOR: <span className="line-through text-gray-500">R$ 497,00</span></span>
                  </div>
                  <span className="bg-green-600/20 text-green-500 px-3 py-1 rounded-lg text-xs font-black uppercase">GRÁTIS HOJE</span>
                </div>
              </div>
            </motion.div>

            {/* Bonus 2 */}
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="group relative bg-gradient-to-br from-gray-900 to-black p-1 rounded-[2.5rem] overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-red-600 opacity-20 group-hover:opacity-40 transition-opacity"></div>
              <div className="relative bg-[#0a0a0a] p-8 md:p-12 rounded-[2.4rem] h-full flex flex-col">
                <div className="flex items-start justify-between mb-8">
                  <div className="bg-orange-600/20 p-4 rounded-2xl border border-orange-600/30">
                    <Target className="w-10 h-10 text-orange-500" />
                  </div>
                  <span className="text-orange-500 font-black text-xl">BÔNUS #02</span>
                </div>
                
                <h3 className="text-3xl font-black mb-4 leading-tight">
                  IA ANALISTA DE <span className="text-orange-500">CRIATIVOS PRO</span>
                </h3>
                <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                  Chega de queimar dinheiro com anúncios ruins. Nossa IA analisa seus criativos, aponta exatamente onde melhorar e gera a copy perfeita para o Facebook Ads.
                  <span className="text-white font-bold block mt-2">Tenha um especialista em tráfego 24h por dia trabalhando para você.</span>
                </p>
                
                <div className="mt-auto pt-6 border-t border-gray-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="text-sm font-bold text-gray-300">VALOR: <span className="line-through text-gray-500">R$ 397,00</span></span>
                  </div>
                  <span className="bg-green-600/20 text-green-500 px-3 py-1 rounded-lg text-xs font-black uppercase">GRÁTIS HOJE</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mentor Section */}
      <section className="py-24 container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-12 max-w-5xl mx-auto">
          <div className="w-64 h-64 md:w-80 md:h-80 relative">
            <div className="absolute inset-0 bg-orange-600 rounded-full blur-3xl opacity-20"></div>
            <img 
              src="https://rendadigital.net/wp-content/uploads/2026/04/fotoJosueBonfim.webp" 
              alt="Josué Bonfim" 
              className="w-full h-full object-cover rounded-full border-4 border-orange-600 relative z-10"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex-1 text-center md:text-left">
            <p className="text-orange-500 font-bold uppercase tracking-widest mb-2">Quem é o seu mentor?</p>
            <h2 className="text-4xl md:text-6xl font-black mb-6">Josué Bonfim</h2>
            <div className="space-y-4 text-gray-300 text-lg leading-relaxed">
              <p>Empreendedor há mais de 16 anos, dos quais 12 são no marketing digital. Sendo um dos pioneiros nas vendas como afiliado usando o Facebook ads.</p>
              <p>Tenho mais de 30 mil alunos em treinamentos próprios, além do faturamento milionário como afiliado!</p>
              <p className="font-bold text-white italic">"Sou o cara que não precisa aparecer para vender, não precisa de seguidor, nem de afiliados para vender os próprios produtos."</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-[#050505] py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-black mb-4">
              Veja os depoimentos <span className="text-orange-500">dos meus alunos</span>
            </h2>
            <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto">
              Pessoas reais que saíram do zero e hoje faturam com meu método.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <motion.a 
                key={t.id}
                href={t.url}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.02 }}
                className="aspect-video bg-gray-900 rounded-xl overflow-hidden border border-gray-800 relative group cursor-pointer block"
              >
                <img src={t.thumbnail} alt="Testimonial" className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center shadow-lg">
                    <Play className="w-6 h-6 text-white fill-current" />
                  </div>
                </div>
              </motion.a>
            ))}
          </div>
        </div>
      </section>

      {/* Authority Section */}
      <section className="py-24 container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-5xl font-black mb-16">Autoridade reconhecida</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-4xl mx-auto">
          <div className="bg-gray-900/50 p-8 rounded-3xl border border-gray-800">
            <div className="flex items-center justify-center gap-4 mb-6">
              <Instagram className="w-10 h-10 text-pink-500" />
              <span className="text-4xl font-black">+182k</span>
            </div>
            <p className="text-gray-400 font-bold uppercase">No Instagram!</p>
            <div className="mt-8 rounded-xl overflow-hidden border border-gray-800">
              <img src="https://rendadigital.net/wp-content/uploads/2026/04/instagram-josue.webp" alt="Instagram Authority" className="w-full" referrerPolicy="no-referrer" />
            </div>
          </div>

          <div className="bg-gray-900/50 p-8 rounded-3xl border border-gray-800">
            <div className="flex items-center justify-center gap-4 mb-6">
              <Youtube className="w-10 h-10 text-red-600" />
              <span className="text-4xl font-black">+64k</span>
            </div>
            <p className="text-gray-400 font-bold uppercase">No YouTube!</p>
            <div className="mt-8 rounded-xl overflow-hidden border border-gray-800">
              <img src="https://rendadigital.net/wp-content/uploads/2026/04/Captura-de-Tela-2025-10-31-as-14.21.05.webp" alt="YouTube Authority" className="w-full" referrerPolicy="no-referrer" />
            </div>
          </div>
        </div>
      </section>

      {/* Offer Section */}
      <section id="checkout" className="py-24 bg-gradient-to-b from-[#0a0a0a] to-orange-950/10">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-5xl font-black text-center mb-16">
            Escolha o seu <span className="text-orange-500">Plano</span>
          </h2>
          
          <div className="flex flex-col lg:flex-row justify-center items-stretch gap-8 max-w-6xl mx-auto">
            {/* Plano Essencial */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex-1 bg-white text-gray-900 rounded-[2.5rem] p-8 md:p-12 shadow-xl border border-gray-100 flex flex-col"
            >
              <div className="text-center mb-8">
                <h3 className="text-2xl font-black uppercase tracking-tighter mb-4">PLANO ESSENCIAL</h3>
                <div className="flex items-center justify-center gap-3">
                  <span className="text-gray-400 line-through text-lg italic">R$ 97</span>
                  <div className="text-6xl font-black flex items-start">
                    <span className="text-2xl mt-2 mr-1">R$</span>
                    <span>47</span>
                  </div>
                </div>
              </div>

              <ul className="space-y-5 mb-12 flex-grow">
                {[
                  "Acesso completo às aulas do Método Destrava 2.0",
                  "Passo a passo direto para fazer a primeira venda",
                  "Estrutura simples para iniciantes",
                  "Método validado",
                  "Produto validado pronto para começar",
                  "Direcionamento claro para aplicar imediatamente"
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-gray-700 font-medium">
                    <CheckCircle className="w-6 h-6 text-orange-500 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full bg-[#0f172a] hover:bg-black text-white font-black py-6 rounded-2xl shadow-lg transition-all uppercase text-xl tracking-tighter"
              >
                PLANO ESSENCIAL
              </motion.button>
            </motion.div>

            {/* Acesso VIP Acelerado */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex-1 bg-white text-gray-900 rounded-[2.5rem] p-8 md:p-12 shadow-2xl border-4 border-orange-600 relative flex flex-col"
            >
              <div className="absolute -top-5 right-8 bg-orange-600 text-white text-xs font-black px-4 py-2 rounded-lg uppercase tracking-widest shadow-lg">
                MAIS ESCOLHIDO
              </div>

              <div className="text-center mb-8">
                <h3 className="text-2xl font-black uppercase tracking-tighter mb-4 text-orange-600 flex items-center justify-center gap-2">
                  ACESSO VIP ACELERADO <Zap className="w-6 h-6 fill-current" />
                </h3>
                <div className="flex items-center justify-center gap-3">
                  <span className="text-gray-400 line-through text-lg italic">R$ 297</span>
                  <div className="text-6xl font-black text-orange-600 flex items-start">
                    <span className="text-2xl mt-2 mr-1">R$</span>
                    <span>97</span>
                  </div>
                </div>
              </div>

              <ul className="space-y-5 mb-12 flex-grow">
                {[
                  "Tudo do Plano Essencial",
                  "+ Produtos Extras (escala)",
                  "1 ENCONTRO AO VIVO PARA TIRAR DÚVIDAS",
                  "Acesso ao Grupo VIP no WhatsApp",
                  "Acesso à Mentoria de Produto Físico",
                  "Aulas semanais dentro da mentoria",
                  "Ambiente de crescimento acelerado",
                  "IA CLONADORA DE QUIZZES 2026",
                  "IA ANALISTA DE CRIATIVOS PRO"
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-gray-800 font-black italic uppercase text-sm md:text-base">
                    {item.includes("IA") ? (
                      <Gift className="w-6 h-6 text-orange-500 shrink-0" />
                    ) : (
                      <CheckCircle className="w-6 h-6 text-orange-500 shrink-0" />
                    )}
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              <div className="space-y-6">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white font-black py-6 rounded-2xl shadow-xl shadow-orange-600/20 transition-all uppercase text-xl tracking-tighter"
                >
                  ACESSO VIP ACELERADO
                </motion.button>

                <div className="bg-red-50 border border-red-100 p-4 rounded-xl text-center">
                  <p className="text-[10px] md:text-xs font-black text-red-500 uppercase tracking-tighter leading-tight">
                    ⚠️ RESTAM APENAS 30 VAGAS PARA ESTE LOTE COM BÔNUS EXCLUSIVOS
                  </p>
                </div>
              </div>
            </motion.div>
          </div>

          <div className="mt-16 flex flex-col items-center gap-4">
            <div className="flex items-center gap-2 text-gray-400">
              <ShieldCheck className="w-8 h-8 text-orange-500" />
              <p className="text-sm font-bold uppercase tracking-widest">Compra 100% Segura • 7 Dias de Garantia</p>
            </div>
            <img 
              src="https://rendadigital.net/wp-content/uploads/2026/04/selo-garantia-7-dias-small-removebg-preview-1.webp" 
              alt="Selo de Garantia" 
              className="w-24 h-24 object-contain"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 container mx-auto px-4 max-w-3xl">
        <h2 className="text-3xl md:text-5xl font-black text-center mb-16">Perguntas Frequentes</h2>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="border border-gray-800 rounded-2xl overflow-hidden">
              <button 
                onClick={() => setOpenFaq(openFaq === index ? null : index)}
                className="w-full p-6 text-left flex items-center justify-between bg-gray-900/50 hover:bg-gray-900 transition-colors"
              >
                <span className="font-bold text-lg">{faq.question}</span>
                {openFaq === index ? <ChevronUp className="text-orange-500" /> : <ChevronDown className="text-gray-500" />}
              </button>
              {openFaq === index && (
                <div className="p-6 bg-gray-900/30 text-gray-400 leading-relaxed border-t border-gray-800">
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-gray-900 text-center">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center gap-8 mb-12">
            <div className="flex items-center gap-4">
              <div className="text-2xl font-black italic tracking-tighter">SÓCIO<span className="text-orange-500">DIGITAL</span></div>
              <div className="w-px h-8 bg-gray-800"></div>
              <div className="text-xl font-bold text-gray-500">MÉTODO DESTRAVA</div>
            </div>
          </div>
          <p className="text-gray-600 text-sm mb-4">osociodigital.com.br | Todos os direitos reservados 2025</p>
          <p className="text-gray-600 text-xs mb-8">Licenciado para: MARCOS ALVARÃES | contato@osociodigital.com.br</p>
          <div className="flex justify-center gap-6 text-xs text-gray-500">
            <a href="#" className="hover:text-orange-500 transition-colors">Termos e condições</a>
            <a href="#" className="hover:text-orange-500 transition-colors">Política de privacidade</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
